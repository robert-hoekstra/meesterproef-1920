module.exports = {
    "globDirectory": "public/",
    "globPatterns": [
        "*.js",
        "*.css"
    ],
    "swDest": "public/sw.js",
    "swSrc": "./src/js/sw.js",
};
